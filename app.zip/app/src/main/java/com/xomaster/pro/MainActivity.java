package com.xomaster.pro;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        webView = new WebView(this);
        setContentView(webView);

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });

        // ربط جسر البلوتوث الأصلي مع لغة الجافاسكريبت داخل اللعبة
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void startNativeBluetoothConnection() {
                // تفعيل أوامر البلوتوث البرمجية الخاصة بنظام أندرويد هنا
            }

            @JavascriptInterface
            public void sendBluetoothMove(int index, String player) {
                // إرسال الحركة للأجهزة المقترنة مباشرة عبر نظام أندرويد
            }
        }, "AndroidBluetoothBridge");

        // تحميل اللعبة محلياً 100% من داخل ملفات الـ Assets المدمجة في الـ APK
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
